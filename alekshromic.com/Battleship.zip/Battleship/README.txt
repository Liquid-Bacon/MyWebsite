@aleks

Welcome to my battleship game! If you would like to play, please make sure you have some Java 
compiler with a GUI installed like Openbeans/netbeans. Simply put the folder into your 
compiler and run the "Main.java" file to play! Enjoy

-Aleks Hromic